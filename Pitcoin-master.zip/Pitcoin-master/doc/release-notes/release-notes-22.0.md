22.0 Release Notes
==================

Pitcoin Core version 22.0 is now available from:

  <https://pitcoincore.org/bin/pitcoin-core-22.0/>

This release includes new features, various bug fixes and performance
improvements, as well as updated translations.

Please report bugs using the issue tracker at GitHub:

  <https://github.com/pitcoin/pitcoin/issues>

To receive security and update notifications, please subscribe to:

  <https://pitcoincore.org/en/list/announcements/join/>

How to Upgrade
==============

If you are running an older version, shut it down. Wait until it has completely
shut down (which might take a few minutes in some cases), then run the
installer (on Windows) or just copy over `/Applications/Pitcoin-Qt` (on Mac)
or `pitcoind`/`pitcoin-qt` (on Linux).

Upgrading directly from a version of Pitcoin Core that has reached its EOL is
possible, but it might take some time if the data directory needs to be migrated. Old
wallet versions of Pitcoin Core are generally supported.

Compatibility
==============

Pitcoin Core is supported and extensively tested on operating systems
using the Linux kernel, macOS 10.14+, and Windows 7 and newer.  Pitcoin
Core should also work on most other Unix-like systems but is not as
frequently tested on them.  It is not recommended to use Pitcoin Core on
unsupported systems.

From Pitcoin Core 22.0 onwards, macOS versions earlier than 10.14 are no longer supported.

Notable changes
===============

P2P and network changes
-----------------------
- Added support for running Pitcoin Core as an
  [I2P (Invisible Internet Project)](https://en.wikipedia.org/wiki/I2P) service
  and connect to such services. See [i2p.md](https://github.com/pitcoin/pitcoin/blob/22.x/doc/i2p.md) for details. (#20685)
- This release removes support for Tor version 2 hidden services in favor of Tor
  v3 only, as the Tor network [dropped support for Tor
  v2](https://blog.torproject.org/v2-deprecation-timeline) with the release of
  Tor version 0.4.6.  Henceforth, Pitcoin Core ignores Tor v2 addresses; it
  neither rumors them over the network to other peers, nor stores them in memory
  or to `peers.dat`.  (#22050)

- Added NAT-PMP port mapping support via
  [`libnatpmp`](https://miniupnp.tuxfamily.org/libnatpmp.html). (#18077)

New and Updated RPCs
--------------------

- Due to [BIP 350](https://github.com/pitcoin/bips/blob/master/bip-0350.mediawiki)
  being implemented, behavior for all RPCs that accept addresses is changed when
  a native witness version 1 (or higher) is passed. These now require a Bech32m
  encoding instead of a Bech32 one, and Bech32m encoding will be used for such
  addresses in RPC output as well. No version 1 addresses should be created
  for mainnet until consensus rules are adopted that give them meaning
  (as will happen through [BIP 341](https://github.com/pitcoin/bips/blob/master/bip-0341.mediawiki)).
  Once that happens, Bech32m is expected to be used for them, so this shouldn't
  affect any production systems, but may be observed on other networks where such
  addresses already have meaning (like signet). (#20861)

- The `getpeerinfo` RPC returns two new boolean fields, `bip152_hb_to` and
  `bip152_hb_from`, that respectively indicate whether we selected a peer to be
  in compact blocks high-bandwidth mode or whether a peer selected us as a
  compact blocks high-bandwidth peer. High-bandwidth peers send new block
  announcements via a `cmpctblock` message rather than the usual inv/headers
  announcements. See BIP 152 for more details. (#19776)

- `getpeerinfo` no longer returns the following fields: `addnode`, `banscore`,
  and `whitelisted`, which were previously deprecated in 0.21. Instead of
  `addnode`, the `connection_type` field returns manual. Instead of
  `whitelisted`, the `permissions` field indicates if the peer has special
  privileges. The `banscore` field has simply been removed. (#20755)

- The following RPCs:  `gettxout`, `getrawtransaction`, `decoderawtransaction`,
  `decodescript`, `gettransaction`, and REST endpoints: `/rest/tx`,
  `/rest/getutxos`, `/rest/block` deprecated the following fields (which are no
  longer returned in the responses by default): `addresses`, `reqSigs`.
  The `-deprecatedrpc=addresses` flag must be passed for these fields to be
  included in the RPC response. This flag/option will be available only for this major release, after which
  the deprecation will be removed entirely. Note that these fields are attributes of
  the `scriptPubKey` object returned in the RPC response. However, in the response
  of `decodescript` these fields are top-level attributes, and included again as attributes
  of the `scriptPubKey` object. (#20286)

- When creating a hex-encoded pitcoin transaction using the `pitcoin-tx` utility
  with the `-json` option set, the following fields: `addresses`, `reqSigs` are no longer
  returned in the tx output of the response. (#20286)

- The `listbanned` RPC now returns two new numeric fields: `ban_duration` and `time_remaining`.
  Respectively, these new fields indicate the duration of a ban and the time remaining until a ban expires,
  both in seconds. Additionally, the `ban_created` field is repositioned to come before `banned_until`. (#21602)

- The `setban` RPC can ban onion addresses again. This fixes a regression introduced in version 0.21.0. (#20852)

- The `getnodeaddresses` RPC now returns a "network" field indicating the
  network type (ipv4, ipv6, onion, or i2p) for each address.  (#21594)

- `getnodeaddresses` now also accepts a "network" argument (ipv4, ipv6, onion,
  or i2p) to return only addresses of the specified network.  (#21843)

- The `testmempoolaccept` RPC now accepts multiple transactions (still experimental at the moment,
  API may be unstable). This is intended for testing transaction packages with dependency
  relationships; it is not recommended for batch-validating independent transactions. In addition to
  mempool policy, package policies apply: the list cannot contain more than 25 transactions or have a
  total size exceeding 101K virtual bytes, and cannot conflict with (spend the same inputs as) each other or
  the mempool, even if it would be a valid BIP125 replace-by-fee. There are some known limitations to
  the accuracy of the test accept: it's possible for `testmempoolaccept` to return "allowed"=True for a
  group of transactions, but "too-long-mempool-chain" if they are actually submitted. (#20833)

- `addmultisigaddress` and `createmultisig` now support up to 20 keys for
  Segwit addresses. (#20867)

Changes to Wallet or GUI related RPCs can be found in the GUI or Wallet section below.

Build System
------------

- Release binaries are now produced using the new `guix`-based build system.
  The [/doc/release-process.md](/doc/release-process.md) document has been updated accordingly.

Files
-----

- The list of banned hosts and networks (via `setban` RPC) is now saved on disk
  in JSON format in `banlist.json` instead of `banlist.dat`. `banlist.dat` is
  only read on startup if `banlist.json` is not present. Changes are only written to the new
  `banlist.json`. A future version of Pitcoin Core may completely ignore
  `banlist.dat`. (#20966)

New settings
------------

- The `-natpmp` option has been added to use NAT-PMP to map the listening port.
  If both UPnP and NAT-PMP are enabled, a successful allocation from UPnP
  prevails over one from NAT-PMP. (#18077)

Updated settings
----------------

Changes to Wallet or GUI related settings can be found in the GUI or Wallet section below.

- Passing an invalid `-rpcauth` argument now cause pitcoind to fail to start.  (#20461)

Tools and Utilities
-------------------

- A new CLI `-addrinfo` command returns the number of addresses known to the
  node per network type (including Tor v2 versus v3) and total. This can be
  useful to see if the node knows enough addresses in a network to use options
  like `-onlynet=<network>` or to upgrade to this release of Pitcoin Core 22.0
  that supports Tor v3 only.  (#21595)

- A new `-rpcwaittimeout` argument to `pitcoin-cli` sets the timeout
  in seconds to use with `-rpcwait`. If the timeout expires,
  `pitcoin-cli` will report a failure. (#21056)

Wallet
------

- External signers such as hardware wallets can now be used through the new RPC methods `enumeratesigners` and `displayaddress`. Support is also added to the `send` RPC call. This feature is experimental. See [external-signer.md](https://github.com/pitcoin/pitcoin/blob/22.x/doc/external-signer.md) for details. (#16546)

- A new `listdescriptors` RPC is available to inspect the contents of descriptor-enabled wallets.
  The RPC returns public versions of all imported descriptors, including their timestamp and flags.
  For ranged descriptors, it also returns the range boundaries and the next index to generate addresses from. (#20226)

- The `bumpfee` RPC is not available with wallets that have private keys
  disabled. `psbtbumpfee` can be used instead. (#20891)

- The `fundrawtransaction`, `send` and `walletcreatefundedpsbt` RPCs now support an `include_unsafe` option
  that when `true` allows using unsafe inputs to fund the transaction.
  Note that the resulting transaction may become invalid if one of the unsafe inputs disappears.
  If that happens, the transaction must be funded with different inputs and republished. (#21359)

- We now support up to 20 keys in `multi()` and `sortedmulti()` descriptors
  under `wsh()`. (#20867)

- Taproot descriptors can be imported into the wallet only after activation has occurred on the network (e.g. mainnet, testnet, signet) in use. See [descriptors.md](https://github.com/pitcoin/pitcoin/blob/22.x/doc/descriptors.md) for supported descriptors.

GUI changes
-----------

- External signers such as hardware wallets can now be used. These require an external tool such as [HWI](https://github.com/pitcoin-core/HWI) to be installed and configured under Options -> Wallet. When creating a new wallet a new option "External signer" will appear in the dialog. If the device is detected, its name is suggested as the wallet name. The watch-only keys are then automatically imported. Receive addresses can be verified on the device. The send dialog will automatically use the connected device. This feature is experimental and the UI may freeze for a few seconds when performing these actions.

Low-level changes
=================

RPC
---

- The RPC server can process a limited number of simultaneous RPC requests.
  Previously, if this limit was exceeded, the RPC server would respond with
  [status code 500 (`HTTP_INTERNAL_SERVER_ERROR`)](https://en.wikipedia.org/wiki/List_of_HTTP_status_codes#5xx_server_errors).
  Now it returns status code 503 (`HTTP_SERVICE_UNAVAILABLE`). (#18335)

- Error codes have been updated to be more accurate for the following error cases (#18466):
  - `signmessage` now returns RPC_INVALID_ADDRESS_OR_KEY (-5) if the
    passed address is invalid. Previously returned RPC_TYPE_ERROR (-3).
  - `verifymessage` now returns RPC_INVALID_ADDRESS_OR_KEY (-5) if the
    passed address is invalid. Previously returned RPC_TYPE_ERROR (-3).
  - `verifymessage` now returns RPC_TYPE_ERROR (-3) if the passed signature
    is malformed. Previously returned RPC_INVALID_ADDRESS_OR_KEY (-5).

Tests
-----

22.0 change log
===============

A detailed list of changes in this version follows. To keep the list to a manageable length, small refactors and typo fixes are not included, and similar changes are sometimes condensed into one line.

### Consensus
- pitcoin/pitcoin#19438 Introduce deploymentstatus (ajtowns)
- pitcoin/pitcoin#20207 Follow-up extra comments on taproot code and tests (sipa)
- pitcoin/pitcoin#21330 Deal with missing data in signature hashes more consistently (sipa)

### Policy
- pitcoin/pitcoin#18766 Disable fee estimation in blocksonly mode (by removing the fee estimates global) (darosior)
- pitcoin/pitcoin#20497 Add `MAX_STANDARD_SCRIPTSIG_SIZE` to policy (sanket1729)
- pitcoin/pitcoin#20611 Move `TX_MAX_STANDARD_VERSION` to policy (MarcoFalke)

### Mining
- pitcoin/pitcoin#19937, pitcoin/pitcoin#20923 Signet mining utility (ajtowns)

### Block and transaction handling
- pitcoin/pitcoin#14501 Fix possible data race when committing block files (luke-jr)
- pitcoin/pitcoin#15946 Allow maintaining the blockfilterindex when using prune (jonasschnelli)
- pitcoin/pitcoin#18710 Add local thread pool to CCheckQueue (hebasto)
- pitcoin/pitcoin#19521 Coinstats Index (fjahr)
- pitcoin/pitcoin#19806 UTXO snapshot activation (jamesob)
- pitcoin/pitcoin#19905 Remove dead CheckForkWarningConditionsOnNewFork (MarcoFalke)
- pitcoin/pitcoin#19935 Move SaltedHashers to separate file and add some new ones (achow101)
- pitcoin/pitcoin#20054 Remove confusing and useless "unexpected version" warning (MarcoFalke)
- pitcoin/pitcoin#20519 Handle rename failure in `DumpMempool(…)` by using the `RenameOver(…)` return value (practicalswift)
- pitcoin/pitcoin#20749, pitcoin/pitcoin#20750, pitcoin/pitcoin#21055, pitcoin/pitcoin#21270, pitcoin/pitcoin#21525, pitcoin/pitcoin#21391, pitcoin/pitcoin#21767, pitcoin/pitcoin#21866 Prune `g_chainman` usage (dongcarl)
- pitcoin/pitcoin#20833 rpc/validation: enable packages through testmempoolaccept (glozow)
- pitcoin/pitcoin#20834 Locks and docs in ATMP and CheckInputsFromMempoolAndCache (glozow)
- pitcoin/pitcoin#20854 Remove unnecessary try-block (amitiuttarwar)
- pitcoin/pitcoin#20868 Remove redundant check on pindex (jarolrod)
- pitcoin/pitcoin#20921 Don't try to invalidate genesis block in CChainState::InvalidateBlock (theStack)
- pitcoin/pitcoin#20972 Locks: Annotate CTxMemPool::check to require `cs_main` (dongcarl)
- pitcoin/pitcoin#21009 Remove RewindBlockIndex logic (dhruv)
- pitcoin/pitcoin#21025 Guard chainman chainstates with `cs_main` (dongcarl)
- pitcoin/pitcoin#21202 Two small clang lock annotation improvements (amitiuttarwar)
- pitcoin/pitcoin#21523 Run VerifyDB on all chainstates (jamesob)
- pitcoin/pitcoin#21573 Update libsecp256k1 subtree to latest master (sipa)
- pitcoin/pitcoin#21582, pitcoin/pitcoin#21584, pitcoin/pitcoin#21585 Fix assumeutxo crashes (MarcoFalke)
- pitcoin/pitcoin#21681 Fix ActivateSnapshot to use hardcoded nChainTx (jamesob)
- pitcoin/pitcoin#21796 index: Avoid async shutdown on init error (MarcoFalke)
- pitcoin/pitcoin#21946 Document and test lack of inherited signaling in RBF policy (ariard)
- pitcoin/pitcoin#22084 Package testmempoolaccept followups (glozow)
- pitcoin/pitcoin#22102 Remove `Warning:` from warning message printed for unknown new rules (prayank23)
- pitcoin/pitcoin#22112 Force port 0 in I2P (vasild)
- pitcoin/pitcoin#22135 CRegTestParams: Use `args` instead of `gArgs` (kiminuo)
- pitcoin/pitcoin#22146 Reject invalid coin height and output index when loading assumeutxo (MarcoFalke)
- pitcoin/pitcoin#22253 Distinguish between same tx and same-nonwitness-data tx in mempool (glozow)
- pitcoin/pitcoin#22261 Two small fixes to node broadcast logic (jnewbery)
- pitcoin/pitcoin#22415 Make `m_mempool` optional in CChainState (jamesob)
- pitcoin/pitcoin#22499 Update assumed chain params (sriramdvt)
- pitcoin/pitcoin#22589 net, doc: update I2P hardcoded seeds and docs for 22.0 (jonatack)

### P2P protocol and network code
- pitcoin/pitcoin#18077 Add NAT-PMP port forwarding support (hebasto)
- pitcoin/pitcoin#18722 addrman: improve performance by using more suitable containers (vasild)
- pitcoin/pitcoin#18819 Replace `cs_feeFilter` with simple std::atomic (MarcoFalke)
- pitcoin/pitcoin#19203 Add regression fuzz harness for CVE-2017-18350. Add FuzzedSocket (practicalswift)
- pitcoin/pitcoin#19288 fuzz: Add fuzzing harness for TorController (practicalswift)
- pitcoin/pitcoin#19415 Make DNS lookup mockable, add fuzzing harness (practicalswift)
- pitcoin/pitcoin#19509 Per-Peer Message Capture (troygiorshev)
- pitcoin/pitcoin#19763 Don't try to relay to the address' originator (vasild)
- pitcoin/pitcoin#19771 Replace enum CConnMan::NumConnections with enum class ConnectionDirection (luke-jr)
- pitcoin/pitcoin#19776 net, rpc: expose high bandwidth mode state via getpeerinfo (theStack)
- pitcoin/pitcoin#19832 Put disconnecting logs into BCLog::NET category (hebasto)
- pitcoin/pitcoin#19858 Periodically make block-relay connections and sync headers (sdaftuar)
- pitcoin/pitcoin#19884 No delay in adding fixed seeds if -dnsseed=0 and peers.dat is empty (dhruv)
- pitcoin/pitcoin#20079 Treat handshake misbehavior like unknown message (MarcoFalke)
- pitcoin/pitcoin#20138 Assume that SetCommonVersion is called at most once per peer (MarcoFalke)
- pitcoin/pitcoin#20162 p2p: declare Announcement::m_state as uint8_t, add getter/setter (jonatack)
- pitcoin/pitcoin#20197 Protect onions in AttemptToEvictConnection(), add eviction protection test coverage (jonatack)
- pitcoin/pitcoin#20210 assert `CNode::m_inbound_onion` is inbound in ctor, add getter, unit tests (jonatack)
- pitcoin/pitcoin#20228 addrman: Make addrman a top-level component (jnewbery)
- pitcoin/pitcoin#20234 Don't bind on 0.0.0.0 if binds are restricted to Tor (vasild)
- pitcoin/pitcoin#20477 Add unit testing of node eviction logic (practicalswift)
- pitcoin/pitcoin#20516 Well-defined CAddress disk serialization, and addrv2 anchors.dat (sipa)
- pitcoin/pitcoin#20557 addrman: Fix new table bucketing during unserialization (jnewbery)
- pitcoin/pitcoin#20561 Periodically clear `m_addr_known` (sdaftuar)
- pitcoin/pitcoin#20599 net processing: Tolerate sendheaders and sendcmpct messages before verack (jnewbery)
- pitcoin/pitcoin#20616 Check CJDNS address is valid (lontivero)
- pitcoin/pitcoin#20617 Remove `m_is_manual_connection` from CNodeState (ariard)
- pitcoin/pitcoin#20624 net processing: Remove nStartingHeight check from block relay (jnewbery)
- pitcoin/pitcoin#20651 Make p2p recv buffer timeout 20 minutes for all peers (jnewbery)
- pitcoin/pitcoin#20661 Only select from addrv2-capable peers for torv3 address relay (sipa)
- pitcoin/pitcoin#20685 Add I2P support using I2P SAM (vasild)
- pitcoin/pitcoin#20690 Clean up logging of outbound connection type (sdaftuar)
- pitcoin/pitcoin#20721 Move ping data to `net_processing` (jnewbery)
- pitcoin/pitcoin#20724 Cleanup of -debug=net log messages (ajtowns)
- pitcoin/pitcoin#20747 net processing: Remove dropmessagestest (jnewbery)
- pitcoin/pitcoin#20764 cli -netinfo peer connections dashboard updates 🎄 ✨ (jonatack)
- pitcoin/pitcoin#20788 add RAII socket and use it instead of bare SOCKET (vasild)
- pitcoin/pitcoin#20791 remove unused legacyWhitelisted in AcceptConnection() (jonatack)
- pitcoin/pitcoin#20816 Move RecordBytesSent() call out of `cs_vSend` lock (jnewbery)
- pitcoin/pitcoin#20845 Log to net debug in MaybeDiscourageAndDisconnect except for noban and manual peers (MarcoFalke)
- pitcoin/pitcoin#20864 Move SocketSendData lock annotation to header (MarcoFalke)
- pitcoin/pitcoin#20965 net, rpc:  return `NET_UNROUTABLE` as `not_publicly_routable`, automate helps (jonatack)
- pitcoin/pitcoin#20966 banman: save the banlist in a JSON format on disk (vasild)
- pitcoin/pitcoin#21015 Make all of `net_processing` (and some of net) use std::chrono types (dhruv)
- pitcoin/pitcoin#21029 pitcoin-cli: Correct docs (no "generatenewaddress" exists) (luke-jr)
- pitcoin/pitcoin#21148 Split orphan handling from `net_processing` into txorphanage (ajtowns)
- pitcoin/pitcoin#21162 Net Processing: Move RelayTransaction() into PeerManager (jnewbery)
- pitcoin/pitcoin#21167 make `CNode::m_inbound_onion` public, initialize explicitly (jonatack)
- pitcoin/pitcoin#21186 net/net processing: Move addr data into `net_processing` (jnewbery)
- pitcoin/pitcoin#21187 Net processing: Only call PushAddress() from `net_processing` (jnewbery)
- pitcoin/pitcoin#21198 Address outstanding review comments from PR20721 (jnewbery)
- pitcoin/pitcoin#21222 log: Clarify log message when file does not exist (MarcoFalke)
- pitcoin/pitcoin#21235 Clarify disconnect log message in ProcessGetBlockData, remove send bool (MarcoFalke)
- pitcoin/pitcoin#21236 Net processing: Extract `addr` send functionality into MaybeSendAddr() (jnewbery)
- pitcoin/pitcoin#21261 update inbound eviction protection for multiple networks, add I2P peers (jonatack)
- pitcoin/pitcoin#21328 net, refactor: pass uint16 CService::port as uint16 (jonatack)
- pitcoin/pitcoin#21387 Refactor sock to add I2P fuzz and unit tests (vasild)
- pitcoin/pitcoin#21395 Net processing: Remove unused CNodeState.address member (jnewbery)
- pitcoin/pitcoin#21407 i2p: limit the size of incoming messages (vasild)
- pitcoin/pitcoin#21506 p2p, refactor: make NetPermissionFlags an enum class (jonatack)
- pitcoin/pitcoin#21509 Don't send FEEFILTER in blocksonly mode (mzumsande)
- pitcoin/pitcoin#21560 Add Tor v3 hardcoded seeds (laanwj)
- pitcoin/pitcoin#21563 Restrict period when `cs_vNodes` mutex is locked (hebasto)
- pitcoin/pitcoin#21564 Avoid calling getnameinfo when formatting IPv4 addresses in CNetAddr::ToStringIP (practicalswift)
- pitcoin/pitcoin#21631 i2p: always check the return value of Sock::Wait() (vasild)
- pitcoin/pitcoin#21644 p2p, bugfix: use NetPermissions::HasFlag() in CConnman::Bind() (jonatack)
- pitcoin/pitcoin#21659 flag relevant Sock methods with [[nodiscard]] (vasild)
- pitcoin/pitcoin#21750 remove unnecessary check of `CNode::cs_vSend` (vasild)
- pitcoin/pitcoin#21756 Avoid calling `getnameinfo` when formatting IPv6 addresses in `CNetAddr::ToStringIP` (practicalswift)
- pitcoin/pitcoin#21775 Limit `m_block_inv_mutex` (MarcoFalke)
- pitcoin/pitcoin#21825 Add I2P hardcoded seeds (jonatack)
- pitcoin/pitcoin#21843 p2p, rpc: enable GetAddr, GetAddresses, and getnodeaddresses by network (jonatack)
- pitcoin/pitcoin#21845 net processing: Don't require locking `cs_main` before calling RelayTransactions() (jnewbery)
- pitcoin/pitcoin#21872 Sanitize message type for logging (laanwj)
- pitcoin/pitcoin#21914 Use stronger AddLocal() for our I2P address (vasild)
- pitcoin/pitcoin#21985 Return IPv6 scope id in `CNetAddr::ToStringIP()` (laanwj)
- pitcoin/pitcoin#21992 Remove -feefilter option (amadeuszpawlik)
- pitcoin/pitcoin#21996 Pass strings to NetPermissions::TryParse functions by const ref (jonatack)
- pitcoin/pitcoin#22013 ignore block-relay-only peers when skipping DNS seed (ajtowns)
- pitcoin/pitcoin#22050 Remove tor v2 support (jonatack)
- pitcoin/pitcoin#22096 AddrFetch - don't disconnect on self-announcements (mzumsande)
- pitcoin/pitcoin#22141 net processing: Remove hash and fValidatedHeaders from QueuedBlock (jnewbery)
- pitcoin/pitcoin#22144 Randomize message processing peer order (sipa)
- pitcoin/pitcoin#22147 Protect last outbound HB compact block peer (sdaftuar)
- pitcoin/pitcoin#22179 Torv2 removal followups (vasild)
- pitcoin/pitcoin#22211 Relay I2P addresses even if not reachable (by us) (vasild)
- pitcoin/pitcoin#22284 Performance improvements to ProtectEvictionCandidatesByRatio() (jonatack)
- pitcoin/pitcoin#22387 Rate limit the processing of rumoured addresses (sipa)
- pitcoin/pitcoin#22455 addrman: detect on-disk corrupted nNew and nTried during unserialization (vasild)

### Wallet
- pitcoin/pitcoin#15710 Catch `ios_base::failure` specifically (Bushstar)
- pitcoin/pitcoin#16546 External signer support - Wallet Box edition (Sjors)
- pitcoin/pitcoin#17331 Use effective values throughout coin selection (achow101)
- pitcoin/pitcoin#18418 Increase `OUTPUT_GROUP_MAX_ENTRIES` to 100 (fjahr)
- pitcoin/pitcoin#18842 Mark replaced tx to not be in the mempool anymore (MarcoFalke)
- pitcoin/pitcoin#19136 Add `parent_desc` to `getaddressinfo` (achow101)
- pitcoin/pitcoin#19137 wallettool: Add dump and createfromdump commands (achow101)
- pitcoin/pitcoin#19651 `importdescriptor`s update existing (S3RK)
- pitcoin/pitcoin#20040 Refactor OutputGroups to handle fees and spending eligibility on grouping (achow101)
- pitcoin/pitcoin#20202 Make BDB support optional (achow101)
- pitcoin/pitcoin#20226, pitcoin/pitcoin#21277, - pitcoin/pitcoin#21063 Add `listdescriptors` command (S3RK)
- pitcoin/pitcoin#20267 Disable and fix tests for when BDB is not compiled (achow101)
- pitcoin/pitcoin#20275 List all wallets in non-SQLite and non-BDB builds (ryanofsky)
- pitcoin/pitcoin#20365 wallettool: Add parameter to create descriptors wallet (S3RK)
- pitcoin/pitcoin#20403 `upgradewallet` fixes, improvements, test coverage (jonatack)
- pitcoin/pitcoin#20448 `unloadwallet`: Allow specifying `wallet_name` param matching RPC endpoint wallet (luke-jr)
- pitcoin/pitcoin#20536 Error with "Transaction too large" if the funded tx will end up being too large after signing (achow101)
- pitcoin/pitcoin#20687 Add missing check for -descriptors wallet tool option (MarcoFalke)
- pitcoin/pitcoin#20952 Add BerkeleyDB version sanity check at init time (laanwj)
- pitcoin/pitcoin#21127 Load flags before everything else (Sjors)
- pitcoin/pitcoin#21141 Add new format string placeholders for walletnotify (maayank)
- pitcoin/pitcoin#21238 A few descriptor improvements to prepare for Taproot support (sipa)
- pitcoin/pitcoin#21302 `createwallet` examples for descriptor wallets (S3RK)
- pitcoin/pitcoin#21329 descriptor wallet: Cache last hardened xpub and use in normalized descriptors (achow101)
- pitcoin/pitcoin#21365 Basic Taproot signing support for descriptor wallets (sipa)
- pitcoin/pitcoin#21417 Misc external signer improvement and HWI 2 support (Sjors)
- pitcoin/pitcoin#21467 Move external signer out of wallet module (Sjors)
- pitcoin/pitcoin#21572 Fix wrong wallet RPC context set after #21366 (ryanofsky)
- pitcoin/pitcoin#21574 Drop JSONRPCRequest constructors after #21366 (ryanofsky)
- pitcoin/pitcoin#21666 Miscellaneous external signer changes (fanquake)
- pitcoin/pitcoin#21759 Document coin selection code (glozow)
- pitcoin/pitcoin#21786 Ensure sat/vB feerates are in range (mantissa of 3) (jonatack)
- pitcoin/pitcoin#21944 Fix issues when `walletdir` is root directory (prayank23)
- pitcoin/pitcoin#22042 Replace size/weight estimate tuple with struct for named fields (instagibbs)
- pitcoin/pitcoin#22051 Basic Taproot derivation support for descriptors (sipa)
- pitcoin/pitcoin#22154 Add OutputType::BECH32M and related wallet support for fetching bech32m addresses (achow101)
- pitcoin/pitcoin#22156 Allow tr() import only when Taproot is active (achow101)
- pitcoin/pitcoin#22166 Add support for inferring tr() descriptors (sipa)
- pitcoin/pitcoin#22173 Do not load external signers wallets when unsupported (achow101)
- pitcoin/pitcoin#22308 Add missing BlockUntilSyncedToCurrentChain (MarcoFalke)
- pitcoin/pitcoin#22334 Do not spam about non-existent spk managers (S3RK)
- pitcoin/pitcoin#22379 Erase spkmans rather than setting to nullptr (achow101)
- pitcoin/pitcoin#22421 Make IsSegWitOutput return true for taproot outputs (sipa)
- pitcoin/pitcoin#22461 Change ScriptPubKeyMan::Upgrade default to True (achow101)
- pitcoin/pitcoin#22492 Reorder locks in dumpwallet to avoid lock order assertion (achow101)
- pitcoin/pitcoin#22686 Use GetSelectionAmount in ApproximateBestSubset (achow101)

### RPC and other APIs
- pitcoin/pitcoin#18335, pitcoin/pitcoin#21484 cli: Print useful error if pitcoind rpc work queue exceeded (LarryRuane)
- pitcoin/pitcoin#18466 Fix invalid parameter error codes for `{sign,verify}message` RPCs (theStack)
- pitcoin/pitcoin#18772 Calculate fees in `getblock` using BlockUndo data (robot-visions)
- pitcoin/pitcoin#19033 http: Release work queue after event base finish (promag)
- pitcoin/pitcoin#19055 Add MuHash3072 implementation (fjahr)
- pitcoin/pitcoin#19145 Add `hash_type` MUHASH for gettxoutsetinfo (fjahr)
- pitcoin/pitcoin#19847 Avoid duplicate set lookup in `gettxoutproof` (promag)
- pitcoin/pitcoin#20286 Deprecate `addresses` and `reqSigs` from RPC outputs (mjdietzx)
- pitcoin/pitcoin#20459 Fail to return undocumented return values (MarcoFalke)
- pitcoin/pitcoin#20461 Validate `-rpcauth` arguments (promag)
- pitcoin/pitcoin#20556 Properly document return values (`submitblock`, `gettxout`, `getblocktemplate`, `scantxoutset`) (MarcoFalke)
- pitcoin/pitcoin#20755 Remove deprecated fields from `getpeerinfo` (amitiuttarwar)
- pitcoin/pitcoin#20832 Better error messages for invalid addresses (eilx2)
- pitcoin/pitcoin#20867 Support up to 20 keys for multisig under Segwit context (darosior)
- pitcoin/pitcoin#20877 cli: `-netinfo` user help and argument parsing improvements (jonatack)
- pitcoin/pitcoin#20891 Remove deprecated bumpfee behavior (achow101)
- pitcoin/pitcoin#20916 Return wtxid from `testmempoolaccept` (MarcoFalke)
- pitcoin/pitcoin#20917 Add missing signet mentions in network name lists (theStack)
- pitcoin/pitcoin#20941 Document `RPC_TRANSACTION_ALREADY_IN_CHAIN` exception (jarolrod)
- pitcoin/pitcoin#20944 Return total fee in `getmempoolinfo` (MarcoFalke)
- pitcoin/pitcoin#20964 Add specific error code for "wallet already loaded" (laanwj)
- pitcoin/pitcoin#21053 Document {previous,next}blockhash as optional (theStack)
- pitcoin/pitcoin#21056 Add a `-rpcwaittimeout` parameter to limit time spent waiting (cdecker)
- pitcoin/pitcoin#21192 cli: Treat high detail levels as maximum in `-netinfo` (laanwj)
- pitcoin/pitcoin#21311 Document optional fields for `getchaintxstats` result (theStack)
- pitcoin/pitcoin#21359 `include_unsafe` option for fundrawtransaction (t-bast)
- pitcoin/pitcoin#21426 Remove `scantxoutset` EXPERIMENTAL warning (jonatack)
- pitcoin/pitcoin#21544 Missing doc updates for bumpfee psbt update (MarcoFalke)
- pitcoin/pitcoin#21594 Add `network` field to `getnodeaddresses` (jonatack)
- pitcoin/pitcoin#21595, pitcoin/pitcoin#21753 cli: Create `-addrinfo` (jonatack)
- pitcoin/pitcoin#21602 Add additional ban time fields to `listbanned` (jarolrod)
- pitcoin/pitcoin#21679 Keep default argument value in correct type (promag)
- pitcoin/pitcoin#21718 Improve error message for `getblock` invalid datatype (klementtan)
- pitcoin/pitcoin#21913 RPCHelpMan fixes (kallewoof)
- pitcoin/pitcoin#22021 `bumpfee`/`psbtbumpfee` fixes and updates (jonatack)
- pitcoin/pitcoin#22043 `addpeeraddress` test coverage, code simplify/constness (jonatack)
- pitcoin/pitcoin#22327 cli: Avoid truncating `-rpcwaittimeout` (MarcoFalke)

### GUI
- pitcoin/pitcoin#18948 Call setParent() in the parent's context (hebasto)
- pitcoin/pitcoin#20482 Add depends qt fix for ARM macs (jonasschnelli)
- pitcoin/pitcoin#21836 scripted-diff: Replace three dots with ellipsis in the ui strings (hebasto)
- pitcoin/pitcoin#21935 Enable external signer support for GUI builds (Sjors)
- pitcoin/pitcoin#22133 Make QWindowsVistaStylePlugin available again (regression) (hebasto)
- pitcoin-core/gui#4 UI external signer support (e.g. hardware wallet) (Sjors)
- pitcoin-core/gui#13 Hide peer detail view if multiple are selected (promag)
- pitcoin-core/gui#18 Add peertablesortproxy module (hebasto)
- pitcoin-core/gui#21 Improve pruning tooltip (fluffypony, PitcoinErrorLog)
- pitcoin-core/gui#72 Log static plugins meta data and used style (hebasto)
- pitcoin-core/gui#79 Embed monospaced font (hebasto)
- pitcoin-core/gui#85 Remove unused "What's This" button in dialogs on Windows OS (hebasto)
- pitcoin-core/gui#115 Replace "Hide tray icon" option with positive "Show tray icon" one (hebasto)
- pitcoin-core/gui#118 Remove BDB version from the Information tab (hebasto)
- pitcoin-core/gui#121 Early subscribe core signals in transaction table model (promag)
- pitcoin-core/gui#123 Do not accept command while executing another one (hebasto)
- pitcoin-core/gui#125 Enable changing the autoprune block space size in intro dialog (luke-jr)
- pitcoin-core/gui#138 Unlock encrypted wallet "OK" button bugfix (mjdietzx)
- pitcoin-core/gui#139 doc: Improve gui/src/qt README.md (jarolrod)
- pitcoin-core/gui#154 Support macOS Dark mode (goums, Uplab)
- pitcoin-core/gui#162 Add network to peers window and peer details (jonatack)
- pitcoin-core/gui#163, pitcoin-core/gui#180 Peer details: replace Direction with Connection Type (jonatack)
- pitcoin-core/gui#164 Handle peer addition/removal in a right way (hebasto)
- pitcoin-core/gui#165 Save QSplitter state in QSettings (hebasto)
- pitcoin-core/gui#173 Follow Qt docs when implementing rowCount and columnCount (hebasto)
- pitcoin-core/gui#179 Add Type column to peers window, update peer details name/tooltip (jonatack)
- pitcoin-core/gui#186 Add information to "Confirm fee bump" window (prayank23)
- pitcoin-core/gui#189 Drop workaround for QTBUG-42503 which was fixed in Qt 5.5.0 (prusnak)
- pitcoin-core/gui#194 Save/restore RPCConsole geometry only for window (hebasto)
- pitcoin-core/gui#202 Fix right panel toggle in peers tab (RandyMcMillan)
- pitcoin-core/gui#203 Display plain "Inbound" in peer details (jonatack)
- pitcoin-core/gui#204 Drop buggy TableViewLastColumnResizingFixer class (hebasto)
- pitcoin-core/gui#205, pitcoin-core/gui#229 Save/restore TransactionView and recentRequestsView tables column sizes (hebasto)
- pitcoin-core/gui#206 Display fRelayTxes and `bip152_highbandwidth_{to, from}` in peer details (jonatack)
- pitcoin-core/gui#213 Add Copy Address Action to Payment Requests (jarolrod)
- pitcoin-core/gui#214 Disable requests context menu actions when appropriate (jarolrod)
- pitcoin-core/gui#217 Make warning label look clickable (jarolrod)
- pitcoin-core/gui#219 Prevent the main window popup menu (hebasto)
- pitcoin-core/gui#220 Do not translate file extensions (hebasto)
- pitcoin-core/gui#221 RPCConsole translatable string fixes and improvements (jonatack)
- pitcoin-core/gui#226 Add "Last Block" and "Last Tx" rows to peer details area (jonatack)
- pitcoin-core/gui#233 qt test: Don't bind to regtest port (achow101)
- pitcoin-core/gui#243 Fix issue when disabling the auto-enabled blank wallet checkbox (jarolrod)
- pitcoin-core/gui#246 Revert "qt: Use "fusion" style on macOS Big Sur with old Qt" (hebasto)
- pitcoin-core/gui#248 For values of "Bytes transferred" and "Bytes/s" with 1000-based prefix names use 1000-based divisor instead of 1024-based (wodry)
- pitcoin-core/gui#251 Improve URI/file handling message (hebasto)
- pitcoin-core/gui#256 Save/restore column sizes of the tables in the Peers tab (hebasto)
- pitcoin-core/gui#260 Handle exceptions isntead of crash (hebasto)
- pitcoin-core/gui#263 Revamp context menus (hebasto)
- pitcoin-core/gui#271 Don't clear console prompt when font resizing (jarolrod)
- pitcoin-core/gui#275 Support runtime appearance adjustment on macOS (hebasto)
- pitcoin-core/gui#276 Elide long strings in their middle in the Peers tab (hebasto)
- pitcoin-core/gui#281 Set shortcuts for console's resize buttons (jarolrod)
- pitcoin-core/gui#293 Enable wordWrap for Services (RandyMcMillan)
- pitcoin-core/gui#296 Do not use QObject::tr plural syntax for numbers with a unit symbol (hebasto)
- pitcoin-core/gui#297 Avoid unnecessary translations (hebasto)
- pitcoin-core/gui#298 Peertableview alternating row colors (RandyMcMillan)
- pitcoin-core/gui#300 Remove progress bar on modal overlay (brunoerg)
- pitcoin-core/gui#309 Add access to the Peers tab from the network icon (hebasto)
- pitcoin-core/gui#311 Peers Window rename 'Peer id' to 'Peer' (jarolrod)
- pitcoin-core/gui#313 Optimize string concatenation by default (hebasto)
- pitcoin-core/gui#325 Align numbers in the "Peer Id" column to the right (hebasto)
- pitcoin-core/gui#329 Make console buttons look clickable (jarolrod)
- pitcoin-core/gui#330 Allow prompt icon to be colorized (jarolrod)
- pitcoin-core/gui#331 Make RPC console welcome message translation-friendly (hebasto)
- pitcoin-core/gui#332 Replace disambiguation strings with translator comments (hebasto)
- pitcoin-core/gui#335 test: Use QSignalSpy instead of QEventLoop (jarolrod)
- pitcoin-core/gui#343 Improve the GUI responsiveness when progress dialogs are used (hebasto)
- pitcoin-core/gui#361 Fix GUI segfault caused by pitcoin/pitcoin#22216 (ryanofsky)
- pitcoin-core/gui#362 Add keyboard shortcuts to context menus (luke-jr)
- pitcoin-core/gui#366 Dark Mode fixes/portability (luke-jr)
- pitcoin-core/gui#375 Emit dataChanged signal to dynamically re-sort Peers table (hebasto)
- pitcoin-core/gui#393 Fix regression in "Encrypt Wallet" menu item (hebasto)
- pitcoin-core/gui#396 Ensure external signer option remains disabled without signers (achow101)
- pitcoin-core/gui#406 Handle new added plurals in `pitcoin_en.ts` (hebasto)

### Build system
- pitcoin/pitcoin#17227 Add Android packaging support (icota)
- pitcoin/pitcoin#17920 guix: Build support for macOS (dongcarl)
- pitcoin/pitcoin#18298 Fix Qt processing of configure script for depends with DEBUG=1 (hebasto)
- pitcoin/pitcoin#19160 multiprocess: Add basic spawn and IPC support (ryanofsky)
- pitcoin/pitcoin#19504 Bump minimum python version to 3.6 (ajtowns)
- pitcoin/pitcoin#19522 fix building libconsensus with reduced exports for Darwin targets (fanquake)
- pitcoin/pitcoin#19683 Pin clang search paths for darwin host (dongcarl)
- pitcoin/pitcoin#19764 Split boost into build/host packages + bump + cleanup (dongcarl)
- pitcoin/pitcoin#19817 libtapi 1100.0.11 (fanquake)
- pitcoin/pitcoin#19846 enable unused member function diagnostic (Zero-1729)
- pitcoin/pitcoin#19867 Document and cleanup Qt hacks (fanquake)
- pitcoin/pitcoin#20046 Set `CMAKE_INSTALL_RPATH` for native packages (ryanofsky)
- pitcoin/pitcoin#20223 Drop the leading 0 from the version number (achow101)
- pitcoin/pitcoin#20333 Remove `native_biplist` dependency (fanquake)
- pitcoin/pitcoin#20353 configure: Support -fdebug-prefix-map and -fmacro-prefix-map (ajtowns)
- pitcoin/pitcoin#20359 Various config.site.in improvements and linting (dongcarl)
- pitcoin/pitcoin#20413 Require C++17 compiler (MarcoFalke)
- pitcoin/pitcoin#20419 Set minimum supported macOS to 10.14 (fanquake)
- pitcoin/pitcoin#20421 miniupnpc 2.2.2 (fanquake)
- pitcoin/pitcoin#20422 Mac deployment unification (fanquake)
- pitcoin/pitcoin#20424 Update univalue subtree (MarcoFalke)
- pitcoin/pitcoin#20449 Fix Windows installer build (achow101)
- pitcoin/pitcoin#20468 Warn when generating man pages for binaries built from a dirty branch (tylerchambers)
- pitcoin/pitcoin#20469 Avoid secp256k1.h include from system (dergoegge)
- pitcoin/pitcoin#20470 Replace genisoimage with xorriso (dongcarl)
- pitcoin/pitcoin#20471 Use C++17 in depends (fanquake)
- pitcoin/pitcoin#20496 Drop unneeded macOS framework dependencies (hebasto)
- pitcoin/pitcoin#20520 Do not force Precompiled Headers (PCH) for building Qt on Linux (hebasto)
- pitcoin/pitcoin#20549 Support make src/pitcoin-node and src/pitcoin-gui (promag)
- pitcoin/pitcoin#20565 Ensure PIC build for bdb on Android (BlockMechanic)
- pitcoin/pitcoin#20594 Fix getauxval calls in randomenv.cpp (jonasschnelli)
- pitcoin/pitcoin#20603 Update crc32c subtree (MarcoFalke)
- pitcoin/pitcoin#20609 configure: output notice that test binary is disabled by fuzzing (apoelstra)
- pitcoin/pitcoin#20619 guix: Quality of life improvements (dongcarl)
- pitcoin/pitcoin#20629 Improve id string robustness (dongcarl)
- pitcoin/pitcoin#20641 Use Qt top-level build facilities (hebasto)
- pitcoin/pitcoin#20650 Drop workaround for a fixed bug in Qt build system (hebasto)
- pitcoin/pitcoin#20673 Use more legible qmake commands in qt package (hebasto)
- pitcoin/pitcoin#20684 Define .INTERMEDIATE target once only (hebasto)
- pitcoin/pitcoin#20720 more robustly check for fcf-protection support (fanquake)
- pitcoin/pitcoin#20734 Make platform-specific targets available for proper platform builds only (hebasto)
- pitcoin/pitcoin#20936 build fuzz tests by default (danben)
- pitcoin/pitcoin#20937 guix: Make nsis reproducible by respecting SOURCE-DATE-EPOCH (dongcarl)
- pitcoin/pitcoin#20938 fix linking against -latomic when building for riscv (fanquake)
- pitcoin/pitcoin#20939 fix `RELOC_SECTION` security check for pitcoin-util (fanquake)
- pitcoin/pitcoin#20963 gitian-linux: Build binaries for 64-bit POWER (continued) (laanwj)
- pitcoin/pitcoin#21036 gitian: Bump descriptors to focal for 22.0 (fanquake)
- pitcoin/pitcoin#21045 Adds switch to enable/disable randomized base address in MSVC builds (EthanHeilman)
- pitcoin/pitcoin#21065 make macOS HOST in download-osx generic (fanquake)
- pitcoin/pitcoin#21078 guix: only download sources for hosts being built (fanquake)
- pitcoin/pitcoin#21116 Disable --disable-fuzz-binary for gitian/guix builds (hebasto)
- pitcoin/pitcoin#21182 remove mostly pointless `BOOST_PROCESS` macro (fanquake)
- pitcoin/pitcoin#21205 actually fail when Boost is missing (fanquake)
- pitcoin/pitcoin#21209 use newer source for libnatpmp (fanquake)
- pitcoin/pitcoin#21226 Fix fuzz binary compilation under windows (danben)
- pitcoin/pitcoin#21231 Add /opt/homebrew to path to look for boost libraries (fyquah)
- pitcoin/pitcoin#21239 guix: Add codesignature attachment support for osx+win (dongcarl)
- pitcoin/pitcoin#21250 Make `HAVE_O_CLOEXEC` available outside LevelDB (bugfix) (theStack)
- pitcoin/pitcoin#21272 guix: Passthrough `SDK_PATH` into container (dongcarl)
- pitcoin/pitcoin#21274 assumptions:  Assume C++17 (fanquake)
- pitcoin/pitcoin#21286 Bump minimum Qt version to 5.9.5 (hebasto)
- pitcoin/pitcoin#21298 guix: Bump time-machine, glibc, and linux-headers (dongcarl)
- pitcoin/pitcoin#21304 guix: Add guix-clean script + establish gc-root for container profiles (dongcarl)
- pitcoin/pitcoin#21320 fix libnatpmp macos cross compile (fanquake)
- pitcoin/pitcoin#21321 guix: Add curl to required tool list (hebasto)
- pitcoin/pitcoin#21333 set Unicode true for NSIS installer (fanquake)
- pitcoin/pitcoin#21339 Make `AM_CONDITIONAL([ENABLE_EXTERNAL_SIGNER])` unconditional (hebasto)
- pitcoin/pitcoin#21349 Fix fuzz-cuckoocache cross-compiling with DEBUG=1 (hebasto)
- pitcoin/pitcoin#21354 build, doc: Drop no longer required packages from macOS cross-compiling dependencies (hebasto)
- pitcoin/pitcoin#21363 build, qt: Improve Qt static plugins/libs check code (hebasto)
- pitcoin/pitcoin#21375 guix: Misc feedback-based fixes + hier restructuring (dongcarl)
- pitcoin/pitcoin#21376 Qt 5.12.10 (fanquake)
- pitcoin/pitcoin#21382 Clean remnants of QTBUG-34748 fix (hebasto)
- pitcoin/pitcoin#21400 Fix regression introduced in #21363 (hebasto)
- pitcoin/pitcoin#21403 set --build when configuring packages in depends (fanquake)
- pitcoin/pitcoin#21421 don't try and use -fstack-clash-protection on Windows (fanquake)
- pitcoin/pitcoin#21423 Cleanups and follow ups after bumping Qt to 5.12.10 (hebasto)
- pitcoin/pitcoin#21427 Fix `id_string` invocations (dongcarl)
- pitcoin/pitcoin#21430 Add -Werror=implicit-fallthrough compile flag (hebasto)
- pitcoin/pitcoin#21457 Split libtapi and clang out of `native_cctools` (fanquake)
- pitcoin/pitcoin#21462 guix: Add guix-{attest,verify} scripts (dongcarl)
- pitcoin/pitcoin#21495 build, qt: Fix static builds on macOS Big Sur (hebasto)
- pitcoin/pitcoin#21497 Do not opt-in unused CoreWLAN stuff in depends for macOS (hebasto)
- pitcoin/pitcoin#21543 Enable safe warnings for msvc builds (hebasto)
- pitcoin/pitcoin#21565 Make `pitcoin_qt.m4` more generic (fanquake)
- pitcoin/pitcoin#21610 remove -Wdeprecated-register from NOWARN flags (fanquake)
- pitcoin/pitcoin#21613 enable -Wdocumentation (fanquake)
- pitcoin/pitcoin#21629 Fix configuring when building depends with `NO_BDB=1` (fanquake)
- pitcoin/pitcoin#21654 build, qt: Make Qt rcc output always deterministic (hebasto)
- pitcoin/pitcoin#21655 build, qt: No longer need to set `QT_RCC_TEST=1` for determinism (hebasto)
- pitcoin/pitcoin#21658 fix make deploy for arm64-darwin (sgulls)
- pitcoin/pitcoin#21694 Use XLIFF file to provide more context to Transifex translators (hebasto)
- pitcoin/pitcoin#21708, pitcoin/pitcoin#21593 Drop pointless sed commands (hebasto)
- pitcoin/pitcoin#21731 Update msvc build to use Qt5.12.10 binaries (sipsorcery)
- pitcoin/pitcoin#21733 Re-add command to install vcpkg (dplusplus1024)
- pitcoin/pitcoin#21793 Use `-isysroot` over `--sysroot` on macOS (fanquake)
- pitcoin/pitcoin#21869 Add missing `-D_LIBCPP_DEBUG=1` to debug flags (MarcoFalke)
- pitcoin/pitcoin#21889 macho: check for control flow instrumentation (fanquake)
- pitcoin/pitcoin#21920 Improve macro for testing -latomic requirement (MarcoFalke)
- pitcoin/pitcoin#21991 libevent 2.1.12-stable (fanquake)
- pitcoin/pitcoin#22054 Bump Qt version to 5.12.11 (hebasto)
- pitcoin/pitcoin#22063 Use Qt archive of the same version as the compiled binaries (hebasto)
- pitcoin/pitcoin#22070 Don't use cf-protection when targeting arm-apple-darwin (fanquake)
- pitcoin/pitcoin#22071 Latest config.guess and config.sub (fanquake)
- pitcoin/pitcoin#22075 guix: Misc leftover usability improvements (dongcarl)
- pitcoin/pitcoin#22123 Fix qt.mk for mac arm64 (promag)
- pitcoin/pitcoin#22174 build, qt: Fix libraries linking order for Linux hosts (hebasto)
- pitcoin/pitcoin#22182 guix: Overhaul how guix-{attest,verify} works and hierarchy (dongcarl)
- pitcoin/pitcoin#22186 build, qt: Fix compiling qt package in depends with GCC 11 (hebasto)
- pitcoin/pitcoin#22199 macdeploy: minor fixups and simplifications (fanquake)
- pitcoin/pitcoin#22230 Fix MSVC linker /SubSystem option for pitcoin-qt.exe (hebasto)
- pitcoin/pitcoin#22234 Mark print-% target as phony (dgoncharov)
- pitcoin/pitcoin#22238 improve detection of eBPF support (fanquake)
- pitcoin/pitcoin#22258 Disable deprecated-copy warning only when external warnings are enabled (MarcoFalke)
- pitcoin/pitcoin#22320 set minimum required Boost to 1.64.0 (fanquake)
- pitcoin/pitcoin#22348 Fix cross build for Windows with Boost Process (hebasto)
- pitcoin/pitcoin#22365 guix: Avoid relying on newer symbols by rebasing our cross toolchains on older glibcs (dongcarl)
- pitcoin/pitcoin#22381 guix: Test security-check sanity before performing them (with macOS) (fanquake)
- pitcoin/pitcoin#22405 Remove --enable-glibc-back-compat from Guix build (fanquake)
- pitcoin/pitcoin#22406 Remove --enable-determinism configure option (fanquake)
- pitcoin/pitcoin#22410 Avoid GCC 7.1 ABI change warning in guix build (sipa)
- pitcoin/pitcoin#22436 use aarch64 Clang if cross-compiling for darwin on aarch64 (fanquake)
- pitcoin/pitcoin#22465 guix: Pin kernel-header version, time-machine to upstream 1.3.0 commit (dongcarl)
- pitcoin/pitcoin#22511 guix: Silence `getent(1)` invocation, doc fixups (dongcarl)
- pitcoin/pitcoin#22531 guix: Fixes to guix-{attest,verify} (achow101)
- pitcoin/pitcoin#22642 release: Release with separate sha256sums and sig files (dongcarl)
- pitcoin/pitcoin#22685 clientversion: No suffix `#if CLIENT_VERSION_IS_RELEASE` (dongcarl)
- pitcoin/pitcoin#22713 Fix build with Boost 1.77.0 (sizeofvoid)

### Tests and QA
- pitcoin/pitcoin#14604 Add test and refactor `feature_block.py` (sanket1729)
- pitcoin/pitcoin#17556 Change `feature_config_args.py` not to rely on strange regtest=0 behavior (ryanofsky)
- pitcoin/pitcoin#18795 wallet issue with orphaned rewards (domob1812)
- pitcoin/pitcoin#18847 compressor: Use a prevector in CompressScript serialization (jb55)
- pitcoin/pitcoin#19259 fuzz: Add fuzzing harness for LoadMempool(…) and DumpMempool(…) (practicalswift)
- pitcoin/pitcoin#19315 Allow outbound & block-relay-only connections in functional tests. (amitiuttarwar)
- pitcoin/pitcoin#19698 Apply strict verification flags for transaction tests and assert backwards compatibility (glozow)
- pitcoin/pitcoin#19801 Check for all possible `OP_CLTV` fail reasons in `feature_cltv.py` (BIP 65) (theStack)
- pitcoin/pitcoin#19893 Remove or explain syncwithvalidationinterfacequeue (MarcoFalke)
- pitcoin/pitcoin#19972 fuzz: Add fuzzing harness for node eviction logic (practicalswift)
- pitcoin/pitcoin#19982 Fix inconsistent lock order in `wallet_tests/CreateWallet` (hebasto)
- pitcoin/pitcoin#20000 Fix creation of "std::string"s with \0s (vasild)
- pitcoin/pitcoin#20047 Use `wait_for_{block,header}` helpers in `p2p_fingerprint.py` (theStack)
- pitcoin/pitcoin#20171 Add functional test `test_txid_inv_delay` (ariard)
- pitcoin/pitcoin#20189 Switch to BIP341's suggested scheme for outputs without script (sipa)
- pitcoin/pitcoin#20248 Fix length of R check in `key_signature_tests` (dgpv)
- pitcoin/pitcoin#20276, pitcoin/pitcoin#20385, pitcoin/pitcoin#20688, pitcoin/pitcoin#20692 Run various mempool tests even with wallet disabled (mjdietzx)
- pitcoin/pitcoin#20323 Create or use existing properly initialized NodeContexts (dongcarl)
- pitcoin/pitcoin#20354 Add `feature_taproot.py --previous_release` (MarcoFalke)
- pitcoin/pitcoin#20370 fuzz: Version handshake (MarcoFalke)
- pitcoin/pitcoin#20377 fuzz: Fill various small fuzzing gaps (practicalswift)
- pitcoin/pitcoin#20425 fuzz: Make CAddrMan fuzzing harness deterministic (practicalswift)
- pitcoin/pitcoin#20430 Sanitizers: Add suppression for unsigned-integer-overflow in libstdc++ (jonasschnelli)
- pitcoin/pitcoin#20437 fuzz: Avoid time-based "non-determinism" in fuzzing harnesses by using mocked GetTime() (practicalswift)
- pitcoin/pitcoin#20458 Add `is_bdb_compiled` helper (Sjors)
- pitcoin/pitcoin#20466 Fix intermittent `p2p_fingerprint` issue (MarcoFalke)
- pitcoin/pitcoin#20472 Add testing of ParseInt/ParseUInt edge cases with leading +/-/0:s (practicalswift)
- pitcoin/pitcoin#20507 sync: print proper lock order location when double lock is detected (vasild)
- pitcoin/pitcoin#20522 Fix sync issue in `disconnect_p2ps` (amitiuttarwar)
- pitcoin/pitcoin#20524 Move `MIN_VERSION_SUPPORTED` to p2p.py (jnewbery)
- pitcoin/pitcoin#20540 Fix `wallet_multiwallet` issue on windows (MarcoFalke)
- pitcoin/pitcoin#20560 fuzz: Link all targets once (MarcoFalke)
- pitcoin/pitcoin#20567 Add option to git-subtree-check to do full check, add help (laanwj)
- pitcoin/pitcoin#20569 Fix intermittent `wallet_multiwallet` issue with `got_loading_error` (MarcoFalke)
- pitcoin/pitcoin#20613 Use Popen.wait instead of RPC in `assert_start_raises_init_error` (MarcoFalke)
- pitcoin/pitcoin#20663 fuzz: Hide `script_assets_test_minimizer` (MarcoFalke)
- pitcoin/pitcoin#20674 fuzz: Call SendMessages after ProcessMessage to increase coverage (MarcoFalke)
- pitcoin/pitcoin#20683 Fix restart node race (MarcoFalke)
- pitcoin/pitcoin#20686 fuzz: replace CNode code with fuzz/util.h::ConsumeNode() (jonatack)
- pitcoin/pitcoin#20733 Inline non-member functions with body in fuzzing headers (pstratem)
- pitcoin/pitcoin#20737 Add missing assignment in `mempool_resurrect.py` (MarcoFalke)
- pitcoin/pitcoin#20745 Correct `epoll_ctl` data race suppression (hebasto)
- pitcoin/pitcoin#20748 Add race:SendZmqMessage tsan suppression (MarcoFalke)
- pitcoin/pitcoin#20760 Set correct nValue for multi-op-return policy check (MarcoFalke)
- pitcoin/pitcoin#20761 fuzz: Check that `NULL_DATA` is unspendable (MarcoFalke)
- pitcoin/pitcoin#20765 fuzz: Check that certain script TxoutType are nonstandard (mjdietzx)
- pitcoin/pitcoin#20772 fuzz: Bolster ExtractDestination(s) checks (mjdietzx)
- pitcoin/pitcoin#20789 fuzz: Rework strong and weak net enum fuzzing (MarcoFalke)
- pitcoin/pitcoin#20828 fuzz: Introduce CallOneOf helper to replace switch-case (MarcoFalke)
- pitcoin/pitcoin#20839 fuzz: Avoid extraneous copy of input data, using Span<> (MarcoFalke)
- pitcoin/pitcoin#20844 Add sanitizer suppressions for AMD EPYC CPUs (MarcoFalke)
- pitcoin/pitcoin#20857 Update documentation in `feature_csv_activation.py` (PiRK)
- pitcoin/pitcoin#20876 Replace getmempoolentry with testmempoolaccept in MiniWallet (MarcoFalke)
- pitcoin/pitcoin#20881 fuzz: net permission flags in net processing (MarcoFalke)
- pitcoin/pitcoin#20882 fuzz: Add missing muhash registration (MarcoFalke)
- pitcoin/pitcoin#20908 fuzz: Use mocktime in `process_message*` fuzz targets (MarcoFalke)
- pitcoin/pitcoin#20915 fuzz: Fail if message type is not fuzzed (MarcoFalke)
- pitcoin/pitcoin#20946 fuzz: Consolidate fuzzing TestingSetup initialization (dongcarl)
- pitcoin/pitcoin#20954 Declare `nodes` type `in test_framework.py` (kiminuo)
- pitcoin/pitcoin#20955 Fix `get_previous_releases.py` for aarch64 (MarcoFalke)
- pitcoin/pitcoin#20969 check that getblockfilter RPC fails without block filter index (theStack)
- pitcoin/pitcoin#20971 Work around libFuzzer deadlock (MarcoFalke)
- pitcoin/pitcoin#20993 Store subversion (user agent) as string in `msg_version` (theStack)
- pitcoin/pitcoin#20995 fuzz: Avoid initializing version to less than `MIN_PEER_PROTO_VERSION` (MarcoFalke)
- pitcoin/pitcoin#20998 Fix BlockToJsonVerbose benchmark (martinus)
- pitcoin/pitcoin#21003 Move MakeNoLogFileContext to `libtest_util`, and use it in bench (MarcoFalke)
- pitcoin/pitcoin#21008 Fix zmq test flakiness, improve speed (theStack)
- pitcoin/pitcoin#21023 fuzz: Disable shuffle when merge=1 (MarcoFalke)
- pitcoin/pitcoin#21037 fuzz: Avoid designated initialization (C++20) in fuzz tests (practicalswift)
- pitcoin/pitcoin#21042 doc, test: Improve `setup_clean_chain` documentation (fjahr)
- pitcoin/pitcoin#21080 fuzz: Configure check for main function (take 2) (MarcoFalke)
- pitcoin/pitcoin#21084 Fix timeout decrease in `feature_assumevalid` (brunoerg)
- pitcoin/pitcoin#21096 Re-add dead code detection (flack)
- pitcoin/pitcoin#21100 Remove unused function `xor_bytes` (theStack)
- pitcoin/pitcoin#21115 Fix Windows cross build (hebasto)
- pitcoin/pitcoin#21117 Remove `assert_blockchain_height` (MarcoFalke)
- pitcoin/pitcoin#21121 Small unit test improvements, including helper to make mempool transaction (amitiuttarwar)
- pitcoin/pitcoin#21124 Remove unnecessary assignment in bdb (brunoerg)
- pitcoin/pitcoin#21125 Change `BOOST_CHECK` to `BOOST_CHECK_EQUAL` for paths (kiminuo)
- pitcoin/pitcoin#21142, pitcoin/pitcoin#21512 fuzz: Add `tx_pool` fuzz target (MarcoFalke)
- pitcoin/pitcoin#21165 Use mocktime in `test_seed_peers` (dhruv)
- pitcoin/pitcoin#21169 fuzz: Add RPC interface fuzzing. Increase fuzzing coverage from 65% to 70% (practicalswift)
- pitcoin/pitcoin#21170 bench: Add benchmark to write json into a string (martinus)
- pitcoin/pitcoin#21178 Run `mempool_reorg.py` even with wallet disabled (DariusParvin)
- pitcoin/pitcoin#21185 fuzz: Remove expensive and redundant muhash from crypto fuzz target (MarcoFalke)
- pitcoin/pitcoin#21200 Speed up `rpc_blockchain.py` by removing miniwallet.generate() (MarcoFalke)
- pitcoin/pitcoin#21211 Move `P2WSH_OP_TRUE` to shared test library (MarcoFalke)
- pitcoin/pitcoin#21228 Avoid comparision of integers with different signs (jonasschnelli)
- pitcoin/pitcoin#21230 Fix `NODE_NETWORK_LIMITED_MIN_BLOCKS` disconnection (MarcoFalke)
- pitcoin/pitcoin#21252 Add missing wait for sync to `feature_blockfilterindex_prune` (MarcoFalke)
- pitcoin/pitcoin#21254 Avoid connecting to real network when running tests (MarcoFalke)
- pitcoin/pitcoin#21264 fuzz: Two scripted diff renames (MarcoFalke)
- pitcoin/pitcoin#21280 Bug fix in `transaction_tests` (glozow)
- pitcoin/pitcoin#21293 Replace accidentally placed bit-OR with logical-OR (hebasto)
- pitcoin/pitcoin#21297 `feature_blockfilterindex_prune.py` improvements (jonatack)
- pitcoin/pitcoin#21310 zmq test: fix sync-up by matching notification to generated block (theStack)
- pitcoin/pitcoin#21334 Additional BIP9 tests (Sjors)
- pitcoin/pitcoin#21338 Add functional test for anchors.dat (brunoerg)
- pitcoin/pitcoin#21345 Bring `p2p_leak.py` up to date (mzumsande)
- pitcoin/pitcoin#21357 Unconditionally check for fRelay field in test framework (jarolrod)
- pitcoin/pitcoin#21358 fuzz: Add missing include (`test/util/setup_common.h`) (MarcoFalke)
- pitcoin/pitcoin#21371 fuzz: fix gcc Woverloaded-virtual build warnings (jonatack)
- pitcoin/pitcoin#21373 Generate fewer blocks in `feature_nulldummy` to fix timeouts, speed up (jonatack)
- pitcoin/pitcoin#21390 Test improvements for UTXO set hash tests (fjahr)
- pitcoin/pitcoin#21410 increase `rpc_timeout` for fundrawtx `test_transaction_too_large` (jonatack)
- pitcoin/pitcoin#21411 add logging, reduce blocks, move `sync_all` in `wallet_` groups (jonatack)
- pitcoin/pitcoin#21438 Add ParseUInt8() test coverage (jonatack)
- pitcoin/pitcoin#21443 fuzz: Implement `fuzzed_dns_lookup_function` as a lambda (practicalswift)
- pitcoin/pitcoin#21445 cirrus: Use SSD cluster for speedup (MarcoFalke)
- pitcoin/pitcoin#21477 Add test for CNetAddr::ToString IPv6 address formatting (RFC 5952) (practicalswift)
- pitcoin/pitcoin#21487 fuzz: Use ConsumeWeakEnum in addrman for service flags (MarcoFalke)
- pitcoin/pitcoin#21488 Add ParseUInt16() unit test and fuzz coverage (jonatack)
- pitcoin/pitcoin#21491 test: remove duplicate assertions in util_tests (jonatack)
- pitcoin/pitcoin#21522 fuzz: Use PickValue where possible (MarcoFalke)
- pitcoin/pitcoin#21531 remove qt byteswap compattests (fanquake)
- pitcoin/pitcoin#21557 small cleanup in RPCNestedTests tests (fanquake)
- pitcoin/pitcoin#21586 Add missing suppression for signed-integer-overflow:txmempool.cpp (MarcoFalke)
- pitcoin/pitcoin#21592 Remove option to make TestChain100Setup non-deterministic (MarcoFalke)
- pitcoin/pitcoin#21597 Document `race:validation_chainstatemanager_tests` suppression (MarcoFalke)
- pitcoin/pitcoin#21599 Replace file level integer overflow suppression with function level suppression (practicalswift)
- pitcoin/pitcoin#21604 Document why no symbol names can be used for suppressions (MarcoFalke)
- pitcoin/pitcoin#21606 fuzz: Extend psbt fuzz target a bit (MarcoFalke)
- pitcoin/pitcoin#21617 fuzz: Fix uninitialized read in i2p test (MarcoFalke)
- pitcoin/pitcoin#21630 fuzz: split FuzzedSock interface and implementation (vasild)
- pitcoin/pitcoin#21634 Skip SQLite fsyncs while testing (achow101)
- pitcoin/pitcoin#21669 Remove spurious double lock tsan suppressions by bumping to clang-12 (MarcoFalke)
- pitcoin/pitcoin#21676 Use mocktime to avoid intermittent failure in `rpc_tests` (MarcoFalke)
- pitcoin/pitcoin#21677 fuzz: Avoid use of low file descriptor ids (which may be in use) in FuzzedSock (practicalswift)
- pitcoin/pitcoin#21678 Fix TestPotentialDeadLockDetected suppression (hebasto)
- pitcoin/pitcoin#21689 Remove intermittently failing and not very meaningful `BOOST_CHECK` in `cnetaddr_basic` (practicalswift)
- pitcoin/pitcoin#21691 Check that no versionbits are re-used (MarcoFalke)
- pitcoin/pitcoin#21707 Extend functional tests for addr relay (mzumsande)
- pitcoin/pitcoin#21712 Test default `include_mempool` value of gettxout (promag)
- pitcoin/pitcoin#21738 Use clang-12 for ASAN, Add missing suppression (MarcoFalke)
- pitcoin/pitcoin#21740 add new python linter to check file names and permissions (windsok)
- pitcoin/pitcoin#21749 Bump shellcheck version (hebasto)
- pitcoin/pitcoin#21754 Run `feature_cltv` with MiniWallet (MarcoFalke)
- pitcoin/pitcoin#21762 Speed up `mempool_spend_coinbase.py` (MarcoFalke)
- pitcoin/pitcoin#21773 fuzz: Ensure prevout is consensus-valid (MarcoFalke)
- pitcoin/pitcoin#21777 Fix `feature_notifications.py` intermittent issue (MarcoFalke)
- pitcoin/pitcoin#21785 Fix intermittent issue in `p2p_addr_relay.py` (MarcoFalke)
- pitcoin/pitcoin#21787 Fix off-by-ones in `rpc_fundrawtransaction` assertions (jonatack)
- pitcoin/pitcoin#21792 Fix intermittent issue in `p2p_segwit.py` (MarcoFalke)
- pitcoin/pitcoin#21795 fuzz: Terminate immediately if a fuzzing harness tries to perform a DNS lookup (belt and suspenders) (practicalswift)
- pitcoin/pitcoin#21798 fuzz: Create a block template in `tx_pool` targets (MarcoFalke)
- pitcoin/pitcoin#21804 Speed up `p2p_segwit.py` (jnewbery)
- pitcoin/pitcoin#21810 fuzz: Various RPC fuzzer follow-ups (practicalswift)
- pitcoin/pitcoin#21814 Fix `feature_config_args.py` intermittent issue (MarcoFalke)
- pitcoin/pitcoin#21821 Add missing test for empty P2WSH redeem (MarcoFalke)
- pitcoin/pitcoin#21822 Resolve bug in `interface_pitcoin_cli.py` (klementtan)
- pitcoin/pitcoin#21846 fuzz: Add `-fsanitize=integer` suppression needed for RPC fuzzer (`generateblock`) (practicalswift)
- pitcoin/pitcoin#21849 fuzz: Limit toxic test globals to their respective scope (MarcoFalke)
- pitcoin/pitcoin#21867 use MiniWallet for `p2p_blocksonly.py` (theStack)
- pitcoin/pitcoin#21873 minor fixes & improvements for files linter test (windsok)
- pitcoin/pitcoin#21874 fuzz: Add `WRITE_ALL_FUZZ_TARGETS_AND_ABORT` (MarcoFalke)
- pitcoin/pitcoin#21884 fuzz: Remove unused --enable-danger-fuzz-link-all option (MarcoFalke)
- pitcoin/pitcoin#21890 fuzz: Limit ParseISO8601DateTime fuzzing to 32-bit (MarcoFalke)
- pitcoin/pitcoin#21891 fuzz: Remove strprintf test cases that are known to fail (MarcoFalke)
- pitcoin/pitcoin#21892 fuzz: Avoid excessively large min fee rate in `tx_pool` (MarcoFalke)
- pitcoin/pitcoin#21895 Add TSA annotations to the WorkQueue class members (hebasto)
- pitcoin/pitcoin#21900 use MiniWallet for `feature_csv_activation.py` (theStack)
- pitcoin/pitcoin#21909 fuzz: Limit max insertions in timedata fuzz test (MarcoFalke)
- pitcoin/pitcoin#21922 fuzz: Avoid timeout in EncodeBase58 (MarcoFalke)
- pitcoin/pitcoin#21927 fuzz: Run const CScript member functions only once (MarcoFalke)
- pitcoin/pitcoin#21929 fuzz: Remove incorrect float round-trip serialization test (MarcoFalke)
- pitcoin/pitcoin#21936 fuzz: Terminate immediately if a fuzzing harness tries to create a TCP socket (belt and suspenders) (practicalswift)
- pitcoin/pitcoin#21941 fuzz: Call const member functions in addrman fuzz test only once (MarcoFalke)
- pitcoin/pitcoin#21945 add P2PK support to MiniWallet (theStack)
- pitcoin/pitcoin#21948 Fix off-by-one in mockscheduler test RPC (MarcoFalke)
- pitcoin/pitcoin#21953 fuzz: Add `utxo_snapshot` target (MarcoFalke)
- pitcoin/pitcoin#21970 fuzz: Add missing CheckTransaction before CheckTxInputs (MarcoFalke)
- pitcoin/pitcoin#21989 Use `COINBASE_MATURITY` in functional tests (kiminuo)
- pitcoin/pitcoin#22003 Add thread safety annotations (ajtowns)
- pitcoin/pitcoin#22004 fuzz: Speed up transaction fuzz target (MarcoFalke)
- pitcoin/pitcoin#22005 fuzz: Speed up banman fuzz target (MarcoFalke)
- pitcoin/pitcoin#22029 [fuzz] Improve transport deserialization fuzz test coverage (dhruv)
- pitcoin/pitcoin#22048 MiniWallet: introduce enum type for output mode (theStack)
- pitcoin/pitcoin#22057 use MiniWallet (P2PK mode) for `feature_dersig.py` (theStack)
- pitcoin/pitcoin#22065 Mark `CheckTxInputs` `[[nodiscard]]`. Avoid UUM in fuzzing harness `coins_view` (practicalswift)
- pitcoin/pitcoin#22069 fuzz: don't try and use fopencookie() when building for Android (fanquake)
- pitcoin/pitcoin#22082 update nanobench from release 4.0.0 to 4.3.4 (martinus)
- pitcoin/pitcoin#22086 remove BasicTestingSetup from unit tests that don't need it (fanquake)
- pitcoin/pitcoin#22089 MiniWallet: fix fee calculation for P2PK and check tx vsize (theStack)
- pitcoin/pitcoin#21107, pitcoin/pitcoin#22092 Convert documentation into type annotations (fanquake)
- pitcoin/pitcoin#22095 Additional BIP32 test vector for hardened derivation with leading zeros (kristapsk)
- pitcoin/pitcoin#22103 Fix IPv6 check on BSD systems (n-thumann)
- pitcoin/pitcoin#22118 check anchors.dat when node starts for the first time (brunoerg)
- pitcoin/pitcoin#22120 `p2p_invalid_block`: Check that a block rejected due to too-new tim… (willcl-ark)
- pitcoin/pitcoin#22153 Fix `p2p_leak.py` intermittent failure (mzumsande)
- pitcoin/pitcoin#22169 p2p, rpc, fuzz: various tiny follow-ups (jonatack)
- pitcoin/pitcoin#22176 Correct outstanding -Werror=sign-compare errors (Empact)
- pitcoin/pitcoin#22180 fuzz: Increase branch coverage of the float fuzz target (MarcoFalke)
- pitcoin/pitcoin#22187 Add `sync_blocks` in `wallet_orphanedreward.py` (domob1812)
- pitcoin/pitcoin#22201 Fix TestShell to allow running in Jupyter Notebook (josibake)
- pitcoin/pitcoin#22202 Add temporary coinstats suppressions (MarcoFalke)
- pitcoin/pitcoin#22203 Use ConnmanTestMsg from test lib in `denialofservice_tests` (MarcoFalke)
- pitcoin/pitcoin#22210 Use MiniWallet in `test_no_inherited_signaling` RBF test (MarcoFalke)
- pitcoin/pitcoin#22224 Update msvc and appveyor builds to use Qt5.12.11 binaries (sipsorcery)
- pitcoin/pitcoin#22249 Kill process group to avoid dangling processes when using `--failfast` (S3RK)
- pitcoin/pitcoin#22267 fuzz: Speed up crypto fuzz target (MarcoFalke)
- pitcoin/pitcoin#22270 Add pitcoin-util tests (+refactors) (MarcoFalke)
- pitcoin/pitcoin#22271 fuzz: Assert roundtrip equality for `CPubKey` (theStack)
- pitcoin/pitcoin#22279 fuzz: add missing ECCVerifyHandle to `base_encode_decode` (apoelstra)
- pitcoin/pitcoin#22292 bench, doc: benchmarking updates and fixups (jonatack)
- pitcoin/pitcoin#22306 Improvements to `p2p_addr_relay.py` (amitiuttarwar)
- pitcoin/pitcoin#22310 Add functional test for replacement relay fee check (ariard)
- pitcoin/pitcoin#22311 Add missing syncwithvalidationinterfacequeue in `p2p_blockfilters` (MarcoFalke)
- pitcoin/pitcoin#22313 Add missing `sync_all` to `feature_coinstatsindex` (MarcoFalke)
- pitcoin/pitcoin#22322 fuzz: Check banman roundtrip (MarcoFalke)
- pitcoin/pitcoin#22363 Use `script_util` helpers for creating P2{PKH,SH,WPKH,WSH} scripts (theStack)
- pitcoin/pitcoin#22399 fuzz: Rework CTxDestination fuzzing (MarcoFalke)
- pitcoin/pitcoin#22408 add tests for `bad-txns-prevout-null` reject reason (theStack)
- pitcoin/pitcoin#22445 fuzz: Move implementations of non-template fuzz helpers from util.h to util.cpp (sriramdvt)
- pitcoin/pitcoin#22446 Fix `wallet_listdescriptors.py` if bdb is not compiled (hebasto)
- pitcoin/pitcoin#22447 Whitelist `rpc_rawtransaction` peers to speed up tests (jonatack)
- pitcoin/pitcoin#22742 Use proper target in `do_fund_send` (S3RK)

### Miscellaneous
- pitcoin/pitcoin#19337 sync: Detect double lock from the same thread (vasild)
- pitcoin/pitcoin#19809 log: Prefix log messages with function name and source code location if -logsourcelocations is set (practicalswift)
- pitcoin/pitcoin#19866 eBPF Linux tracepoints (jb55)
- pitcoin/pitcoin#20024 init: Fix incorrect warning "Reducing -maxconnections from N to N-1, because of system limitations" (practicalswift)
- pitcoin/pitcoin#20145 contrib: Add getcoins.py script to get coins from (signet) faucet (kallewoof)
- pitcoin/pitcoin#20255 util: Add assume() identity function (MarcoFalke)
- pitcoin/pitcoin#20288 script, doc: Contrib/seeds updates (jonatack)
- pitcoin/pitcoin#20358 src/randomenv.cpp: Fix build on uclibc (ffontaine)
- pitcoin/pitcoin#20406 util: Avoid invalid integer negation in formatmoney and valuefromamount (practicalswift)
- pitcoin/pitcoin#20434 contrib: Parse elf directly for symbol and security checks (laanwj)
- pitcoin/pitcoin#20451 lint: Run mypy over contrib/devtools (fanquake)
- pitcoin/pitcoin#20476 contrib: Add test for elf symbol-check (laanwj)
- pitcoin/pitcoin#20530 lint: Update cppcheck linter to c++17 and improve explicit usage (fjahr)
- pitcoin/pitcoin#20589 log: Clarify that failure to read/write `fee_estimates.dat` is non-fatal (MarcoFalke)
- pitcoin/pitcoin#20602 util: Allow use of c++14 chrono literals (MarcoFalke)
- pitcoin/pitcoin#20605 init: Signal-safe instant shutdown (laanwj)
- pitcoin/pitcoin#20608 contrib: Add symbol check test for PE binaries (fanquake)
- pitcoin/pitcoin#20689 contrib: Replace binary verification script verify.sh with python rewrite (theStack)
- pitcoin/pitcoin#20715 util: Add argsmanager::getcommand() and use it in pitcoin-wallet (MarcoFalke)
- pitcoin/pitcoin#20735 script: Remove outdated extract-osx-sdk.sh (hebasto)
- pitcoin/pitcoin#20817 lint: Update list of spelling linter false positives, bump to codespell 2.0.0 (theStack)
- pitcoin/pitcoin#20884 script: Improve robustness of pitcoind.service on startup (hebasto)
- pitcoin/pitcoin#20906 contrib: Embed c++11 patch in `install_db4.sh` (gruve-p)
- pitcoin/pitcoin#21004 contrib: Fix docker args conditional in gitian-build (setpill)
- pitcoin/pitcoin#21007 pitcoind: Add -daemonwait option to wait for initialization (laanwj)
- pitcoin/pitcoin#21041 log: Move "Pre-allocating up to position 0x[…] in […].dat" log message to debug category (practicalswift)
- pitcoin/pitcoin#21059 Drop boost/preprocessor dependencies (hebasto)
- pitcoin/pitcoin#21087 guix: Passthrough `BASE_CACHE` into container (dongcarl)
- pitcoin/pitcoin#21088 guix: Jump forwards in time-machine and adapt (dongcarl)
- pitcoin/pitcoin#21089 guix: Add support for powerpc64{,le} (dongcarl)
- pitcoin/pitcoin#21110 util: Remove boost `posix_time` usage from `gettime*` (fanquake)
- pitcoin/pitcoin#21111 Improve OpenRC initscript (parazyd)
- pitcoin/pitcoin#21123 code style: Add EditorConfig file (kiminuo)
- pitcoin/pitcoin#21173 util: Faster hexstr => 13% faster blocktojson (martinus)
- pitcoin/pitcoin#21221 tools: Allow argument/parameter bin packing in clang-format (jnewbery)
- pitcoin/pitcoin#21244 Move GetDataDir to ArgsManager (kiminuo)
- pitcoin/pitcoin#21255 contrib: Run test-symbol-check for risc-v (fanquake)
- pitcoin/pitcoin#21271 guix: Explicitly set umask in build container (dongcarl)
- pitcoin/pitcoin#21300 script: Add explanatory comment to tc.sh (dscotese)
- pitcoin/pitcoin#21317 util: Make assume() usable as unary expression (MarcoFalke)
- pitcoin/pitcoin#21336 Make .gitignore ignore src/test/fuzz/fuzz.exe (hebasto)
- pitcoin/pitcoin#21337 guix: Update darwin native packages dependencies (hebasto)
- pitcoin/pitcoin#21405 compat: remove memcpy -> memmove backwards compatibility alias (fanquake)
- pitcoin/pitcoin#21418 contrib: Make systemd invoke dependencies only when ready (laanwj)
- pitcoin/pitcoin#21447 Always add -daemonwait to known command line arguments (hebasto)
- pitcoin/pitcoin#21471 bugfix: Fix `bech32_encode` calls in `gen_key_io_test_vectors.py` (sipa)
- pitcoin/pitcoin#21615 script: Add trusted key for hebasto (hebasto)
- pitcoin/pitcoin#21664 contrib: Use lief for macos and windows symbol & security checks (fanquake)
- pitcoin/pitcoin#21695 contrib: Remove no longer used contrib/pitcoin-qt.pro (hebasto)
- pitcoin/pitcoin#21711 guix: Add full installation and usage documentation (dongcarl)
- pitcoin/pitcoin#21799 guix: Use `gcc-8` across the board (dongcarl)
- pitcoin/pitcoin#21802 Avoid UB in util/asmap (advance a dereferenceable iterator outside its valid range) (MarcoFalke)
- pitcoin/pitcoin#21823 script: Update reviewers (jonatack)
- pitcoin/pitcoin#21850 Remove `GetDataDir(net_specific)` function (kiminuo)
- pitcoin/pitcoin#21871 scripts: Add checks for minimum required os versions (fanquake)
- pitcoin/pitcoin#21966 Remove double serialization; use software encoder for fee estimation (sipa)
- pitcoin/pitcoin#22060 contrib: Add torv3 seed nodes for testnet, drop v2 ones (laanwj)
- pitcoin/pitcoin#22244 devtools: Correctly extract symbol versions in symbol-check (laanwj)
- pitcoin/pitcoin#22533 guix/build: Remove vestigial SKIPATTEST.TAG (dongcarl)
- pitcoin/pitcoin#22643 guix-verify: Non-zero exit code when anything fails (dongcarl)
- pitcoin/pitcoin#22654 guix: Don't include directory name in SHA256SUMS (achow101)

### Documentation
- pitcoin/pitcoin#15451 clarify getdata limit after #14897 (HashUnlimited)
- pitcoin/pitcoin#15545 Explain why CheckBlock() is called before AcceptBlock (Sjors)
- pitcoin/pitcoin#17350 Add developer documentation to isminetype (HAOYUatHZ)
- pitcoin/pitcoin#17934 Use `CONFIG_SITE` variable instead of --prefix option (hebasto)
- pitcoin/pitcoin#18030 Coin::IsSpent() can also mean never existed (Sjors)
- pitcoin/pitcoin#18096 IsFinalTx comment about nSequence & `OP_CLTV` (nothingmuch)
- pitcoin/pitcoin#18568 Clarify developer notes about constant naming (ryanofsky)
- pitcoin/pitcoin#19961 doc: tor.md updates (jonatack)
- pitcoin/pitcoin#19968 Clarify CRollingBloomFilter size estimate (robot-dreams)
- pitcoin/pitcoin#20200 Rename CODEOWNERS to REVIEWERS (adamjonas)
- pitcoin/pitcoin#20329 docs/descriptors.md: Remove hardened marker in the path after xpub (dgpv)
- pitcoin/pitcoin#20380 Add instructions on how to fuzz the P2P layer using Honggfuzz NetDriver (practicalswift)
- pitcoin/pitcoin#20414 Remove generated manual pages from master branch (laanwj)
- pitcoin/pitcoin#20473 Document current boost dependency as 1.71.0 (laanwj)
- pitcoin/pitcoin#20512 Add bash as an OpenBSD dependency (emilengler)
- pitcoin/pitcoin#20568 Use FeeModes doc helper in estimatesmartfee (MarcoFalke)
- pitcoin/pitcoin#20577 libconsensus: add missing error code description, fix NPitcoin link (theStack)
- pitcoin/pitcoin#20587 Tidy up Tor doc (more stringent) (wodry)
- pitcoin/pitcoin#20592 Update wtxidrelay documentation per BIP339 (jonatack)
- pitcoin/pitcoin#20601 Update for FreeBSD 12.2, add GUI Build Instructions (jarolrod)
- pitcoin/pitcoin#20635 fix misleading comment about call to non-existing function (pox)
- pitcoin/pitcoin#20646 Refer to BIPs 339/155 in feature negotiation (jonatack)
- pitcoin/pitcoin#20653 Move addr relay comment in net to correct place (MarcoFalke)
- pitcoin/pitcoin#20677 Remove shouty enums in `net_processing` comments (sdaftuar)
- pitcoin/pitcoin#20741 Update 'Secure string handling' (prayank23)
- pitcoin/pitcoin#20757 tor.md and -onlynet help updates (jonatack)
- pitcoin/pitcoin#20829 Add -netinfo help (jonatack)
- pitcoin/pitcoin#20830 Update developer notes with signet (jonatack)
- pitcoin/pitcoin#20890 Add explicit macdeployqtplus dependencies install step (hebasto)
- pitcoin/pitcoin#20913 Add manual page generation for pitcoin-util (laanwj)
- pitcoin/pitcoin#20985 Add xorriso to macOS depends packages (fanquake)
- pitcoin/pitcoin#20986 Update developer notes to discourage very long lines (jnewbery)
- pitcoin/pitcoin#20987 Add instructions for generating RPC docs (ben-kaufman)
- pitcoin/pitcoin#21026 Document use of make-tag script to make tags (laanwj)
- pitcoin/pitcoin#21028 doc/bips: Add BIPs 43, 44, 49, and 84 (luke-jr)
- pitcoin/pitcoin#21049 Add release notes for listdescriptors RPC (S3RK)
- pitcoin/pitcoin#21060 More precise -debug and -debugexclude doc (wodry)
- pitcoin/pitcoin#21077 Clarify -timeout and -peertimeout config options (glozow)
- pitcoin/pitcoin#21105 Correctly identify script type (niftynei)
- pitcoin/pitcoin#21163 Guix is shipped in Debian and Ubuntu (MarcoFalke)
- pitcoin/pitcoin#21210 Rework internal and external links (MarcoFalke)
- pitcoin/pitcoin#21246 Correction for VerifyTaprootCommitment comments (roconnor-blockstream)
- pitcoin/pitcoin#21263 Clarify that squashing should happen before review (MarcoFalke)
- pitcoin/pitcoin#21323 guix, doc: Update default HOSTS value (hebasto)
- pitcoin/pitcoin#21324 Update build instructions for Fedora (hebasto)
- pitcoin/pitcoin#21343 Revamp macOS build doc (jarolrod)
- pitcoin/pitcoin#21346 install qt5 when building on macOS (fanquake)
- pitcoin/pitcoin#21384 doc: add signet to pitcoin.conf documentation (jonatack)
- pitcoin/pitcoin#21394 Improve comment about protected peers (amitiuttarwar)
- pitcoin/pitcoin#21398 Update fuzzing docs for afl-clang-lto (MarcoFalke)
- pitcoin/pitcoin#21444 net, doc: Doxygen updates and fixes in netbase.{h,cpp} (jonatack)
- pitcoin/pitcoin#21481 Tell howto install clang-format on Debian/Ubuntu (wodry)
- pitcoin/pitcoin#21567 Fix various misleading comments (glozow)
- pitcoin/pitcoin#21661 Fix name of script guix-build (Emzy)
- pitcoin/pitcoin#21672 Remove boostrap info from `GUIX_COMMON_FLAGS` doc (fanquake)
- pitcoin/pitcoin#21688 Note on SDK for macOS depends cross-compile (jarolrod)
- pitcoin/pitcoin#21709 Update reduce-memory.md and pitcoin.conf -maxconnections info (jonatack)
- pitcoin/pitcoin#21710 update helps for addnode rpc and -addnode/-maxconnections config options (jonatack)
- pitcoin/pitcoin#21752 Clarify that feerates are per virtual size (MarcoFalke)
- pitcoin/pitcoin#21811 Remove Visual Studio 2017 reference from readme (sipsorcery)
- pitcoin/pitcoin#21818 Fixup -coinstatsindex help, update pitcoin.conf and files.md (jonatack)
- pitcoin/pitcoin#21856 add OSS-Fuzz section to fuzzing.md doc (adamjonas)
- pitcoin/pitcoin#21912 Remove mention of priority estimation (MarcoFalke)
- pitcoin/pitcoin#21925 Update bips.md for 0.21.1 (MarcoFalke)
- pitcoin/pitcoin#21942 improve make with parallel jobs description (klementtan)
- pitcoin/pitcoin#21947 Fix OSS-Fuzz links (MarcoFalke)
- pitcoin/pitcoin#21988 note that brew installed qt is not supported (jarolrod)
- pitcoin/pitcoin#22056 describe in fuzzing.md how to reproduce a CI crash (jonatack)
- pitcoin/pitcoin#22080 add maxuploadtarget to pitcoin.conf example (jarolrod)
- pitcoin/pitcoin#22088 Improve note on choosing posix mingw32 (jarolrod)
- pitcoin/pitcoin#22109 Fix external links (IRC, …) (MarcoFalke)
- pitcoin/pitcoin#22121 Various validation doc fixups (MarcoFalke)
- pitcoin/pitcoin#22172 Update tor.md, release notes with removal of tor v2 support (jonatack)
- pitcoin/pitcoin#22204 Remove obsolete `okSafeMode` RPC guideline from developer notes (theStack)
- pitcoin/pitcoin#22208 Update `REVIEWERS` (practicalswift)
- pitcoin/pitcoin#22250 add basic I2P documentation (vasild)
- pitcoin/pitcoin#22296 Final merge of release notes snippets, mv to wiki (MarcoFalke)
- pitcoin/pitcoin#22335 recommend `--disable-external-signer` in OpenBSD build guide (theStack)
- pitcoin/pitcoin#22339 Document minimum required libc++ version (hebasto)
- pitcoin/pitcoin#22349 Repository IRC updates (jonatack)
- pitcoin/pitcoin#22360 Remove unused section from release process (MarcoFalke)
- pitcoin/pitcoin#22369 Add steps for Transifex to release process (jonatack)
- pitcoin/pitcoin#22393 Added info to pitcoin.conf doc (bliotti)
- pitcoin/pitcoin#22402 Install Rosetta on M1-macOS for qt in depends (hebasto)
- pitcoin/pitcoin#22432 Fix incorrect `testmempoolaccept` doc (glozow)
- pitcoin/pitcoin#22648 doc, test: improve i2p/tor docs and i2p reachable unit tests (jonatack)

Credits
=======

Thanks to everyone who directly contributed to this release:

- Aaron Clauson
- Adam Jonas
- amadeuszpawlik
- Amiti Uttarwar
- Andrew Chow
- Andrew Poelstra
- Anthony Towns
- Antoine Poinsot
- Antoine Riard
- apawlik
- apitko
- Ben Carman
- Ben Woosley
- benk10
- Bezdrighin
- Block Mechanic
- Brian Liotti
- Bruno Garcia
- Carl Dong
- Christian Decker
- coinforensics
- Cory Fields
- Dan Benjamin
- Daniel Kraft
- Darius Parvin
- Dhruv Mehta
- Dmitry Goncharov
- Dmitry Petukhov
- dplusplus1024
- dscotese
- Duncan Dean
- Elle Mouton
- Elliott Jin
- Emil Engler
- Ethan Heilman
- eugene
- Evan Klitzke
- Fabian Jahr
- Fabrice Fontaine
- fanquake
- fdov
- flack
- Fotis Koutoupas
- Fu Yong Quah
- fyquah
- glozow
- Gregory Sanders
- Guido Vranken
- Gunar C. Gessner
- h
- HAOYUatHZ
- Hennadii Stepanov
- Igor Cota
- Ikko Ashimine
- Ivan Metlushko
- jackielove4u
- James O'Beirne
- Jarol Rodriguez
- Joel Klabo
- John Newbery
- Jon Atack
- Jonas Schnelli
- João Barbosa
- Josiah Baker
- Karl-Johan Alm
- Kiminuo
- Klement Tan
- Kristaps Kaupe
- Larry Ruane
- lisa neigut
- Lucas Ontivero
- Luke Dashjr
- Maayan Keshet
- MarcoFalke
- Martin Ankerl
- Martin Zumsande
- Michael Dietz
- Michael Polzer
- Michael Tidwell
- Niklas Gögge
- nthumann
- Oliver Gugger
- parazyd
- Patrick Strateman
- Pavol Rusnak
- Peter Bushnell
- Pierre K
- Pieter Wuille
- PiRK
- pox
- practicalswift
- Prayank
- R E Broadley
- Rafael Sadowski
- randymcmillan
- Raul Siles
- Riccardo Spagni
- Russell O'Connor
- Russell Yanofsky
- S3RK
- saibato
- Samuel Dobson
- sanket1729
- Sawyer Billings
- Sebastian Falbesoner
- setpill
- sgulls
- sinetek
- Sjors Provoost
- Sriram
- Stephan Oeste
- Suhas Daftuar
- Sylvain Goumy
- t-bast
- Troy Giorshev
- Tushar Singla
- Tyler Chambers
- Uplab
- Vasil Dimov
- W. J. van der Laan
- willcl-ark
- William Bright
- William Casarin
- windsok
- wodry
- Yerzhan Mazhkenov
- Yuval Kogman
- Zero

As well as to everyone that helped with translations on
[Transifex](https://www.transifex.com/pitcoin/pitcoin/).
