- unix socket paths are now accepted for `-zmqpubrawblock` and `-zmqpubrawtx` with
the format `-zmqpubrawtx=unix:/path/to/file`