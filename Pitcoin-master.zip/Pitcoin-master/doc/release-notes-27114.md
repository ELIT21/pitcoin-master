- Additional flags "in" and "out" have been added to `-whitelist` to control whether
  permissions apply to incoming connections and/or manual (default: incoming only).