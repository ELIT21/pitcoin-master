Sample configuration files for:
```
systemd: pitcoind.service
Upstart: pitcoind.conf
OpenRC:  pitcoind.openrc
         pitcoind.openrcconf
CentOS:  pitcoind.init
macOS:   org.pitcoin.pitcoind.plist
```
have been made available to assist packagers in creating node packages here.

See [doc/init.md](../../doc/init.md) for more information.
